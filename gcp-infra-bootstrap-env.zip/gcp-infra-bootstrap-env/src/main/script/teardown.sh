#!/usr/bin/env bash


if [ -z $1 ] ; then
        echo "pass the value of environment...e.g. 'teardown.sh dev01'"
        exit 1;
fi

workingDir=`pwd`
baseDir=$workingDir/../../..
tfDir=$baseDir/src/main/terraform
scriptDir=$baseDir/src/main/script
confDir=$baseDir/src/main/config



cd $tfDir
./cleanup.sh
echo 'Cleanup of terraform dir is done....'

rm -rf backend-no-commit.tf
ln -s $confDir/env/$1/backend-$1.tf backend-no-commit.tf

terraform init

terraform destroy -force -target=module.bootstrap \
    -var-file=$confDir/env/$1/env-$1.tfvars -var backend_location=$confDir/env/$1

echo '******** Go ahead and delete the bucket on your own!!!!!'









