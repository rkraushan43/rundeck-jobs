#!/usr/bin/env bash


if [ -z $1 ] ; then
        echo "pass the value of environment...e.g. 'bootstrap.sh dev01'"
        exit 1;
fi

workingDir=`pwd`
baseDir=$workingDir/../../..
tfDir=$baseDir/src/main/terraform
scriptDir=$baseDir/src/main/script
confDir=$baseDir/src/main/config



cd $tfDir
./cleanup.sh
rm -rf backend-no-commit.tf
echo 'Cleanup of terraform dir is done....'

terraform init

#Comment out "module.init" call if Bucket is already existing. This module just creates the bucket in GCP and stores the file in local machine
# in the appropriate environment folder e.g. src/main/config/dev01/backend-dev01.tf

terraform apply -auto-approve -target=module.init \
    -var-file=$confDir/env/$1/env-$1.tfvars -var backend_location=$confDir/env/$1


ln -s $confDir/env/$1/backend-$1.tf backend-no-commit.tf

terraform init

terraform apply -auto-approve -target=module.bootstrap \
    -var-file=$confDir/env/$1/env-$1.tfvars -var backend_location=$confDir/env/$1





