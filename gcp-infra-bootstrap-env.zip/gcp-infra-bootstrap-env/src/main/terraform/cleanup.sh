#!/usr/bin/env bash

rm -rf .terraform
rm -rf terraform.tfstate*
rm -rf errored.tfstate